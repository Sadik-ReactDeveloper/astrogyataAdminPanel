
  export const baseURL = 'http://3.108.185.7/nodejs/api/'
  export const URL = 'https://leadtrackingqa.earlysalary.com/'
 